#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <random>
#include <bits/random.h>
#include <time.h>       /* clock_t, clock, CLOCKS_PER_SEC */
#include "include/BasicCDS.h"
#include <sdsl/suffix_arrays.hpp>
#include "wt_fbb.hpp"

using namespace std;
using namespace sdsl;
using namespace cds;

#define PRINT 0
#define TEST 1
#define MAX 512
uint REPET = 100000;

#define SA_TEST 16				// sampling for the SA in the fmi
#define ISA_TEST 1073741824		// sampling for the SA^-1 in the fmi

typedef struct {
	uint n;		// length of document
	uint nPhra;	// number of LZ77 factors
	uint m;		// number of bits for relative pointer;
	ulong *P;	// array of relative pointers
	uint nWP;
	uchar *C;	// mismatch character for each phrase	(it can be less !)

	bit_vector_il<512> B;
	bit_vector_il<512>::rank_1_type rankB;
	bit_vector_il<512>::select_1_type selB;
} rlzDoc;

typedef struct {
	uchar *ref;				// reference's sequence
	uint d;					// number of documents that will be compress
	rlzDoc *rlz;			// array of rlz structures of length d
	uint sizeDS;			// total size in bytes of this dataStructure

	uint n;					// reference's length
	ulong N;				// length of all collection
	csa_wt<wt_fbb<hyb_vector<> >, SA_TEST, ISA_TEST> fmi;	// FMI of the original text. It is created only if it want to test the index

	char inputFile[400];	// name (with poath) of the file the contains the list of files co compress. The first one will be the reference
	char prefixResult[300];	// Prefix name of results files in the experiments
	uchar **T;				//sequences for test and experiments
} ParamProgram;

void makeRLZ(ParamProgram *par);
void buildFMI(ParamProgram *par);
void runExperimentExtract(ParamProgram *par);
void storeFiles(ParamProgram *par);
void testRLZ(ParamProgram *par);

// /home/hferrada/data/repet/influenza_list10.txt /home/hferrada/data/repet/RLZ/
// listFiles.txt ./
// /home/hferrada/data/repet/influenza_list1k.txt /home/hferrada/data/repet/RLZ/

int main(int argc, char *argv[]) {
	ParamProgram *par = new ParamProgram();

	if(argc != 3){
		cout << "ERROR with parameters... Example: ./compresRLZ ./list.txt ./prefixResult" << endl;
		exit(1);
	}
	strcpy(par->inputFile, "");
	strcpy(par->inputFile, argv[1]);
	strcpy(par->prefixResult, "");
	strcpy(par->prefixResult, argv[2]);

	cout << "Parameters..." << endl;
	cout << "inputFile = " << par->inputFile << endl;
	cout << "prefixResult = " << par->prefixResult << endl;

	double t = clock();
	par->sizeDS = 0;
	buildFMI(par);
	makeRLZ(par);
	t = clock() - t;

	cout << "====================================================" << endl;
	cout << " ### Construction CPU Time : " << ((float)t/CLOCKS_PER_SEC)*1000.0 << " Milliseconds" << endl;
	cout << " ### Collection size       : " << par->N*sizeof(uchar) << " bytes = " << (par->N*sizeof(uchar))/(1024.0*1024.0) << " MiB" << endl;
	cout << " ### Structure size        : " << par->sizeDS << " bytes = " << par->sizeDS/(1024.0*1024.0) << " MiB" << endl;
	cout << " ### Compression Ratio     : " << par->sizeDS/(float)(par->N*sizeof(uchar)) << endl;
	cout << "====================================================" << endl;

	if (TEST)
		testRLZ(par);

	runExperimentExtract(par);
	cout << endl << "$$$ :) $$$" << endl;

	return 0;
}

// extract 'm' symbols from the document 'rDoc' in position 'ini' and stores it in 'str[0..m-1]'
void extractFromSeq(uchar *Text, uint ini, uint m, uchar *str){
	strncpy((char *)str, (char *)(Text)+ini, m);
}

// extract 'm' symbols from the document 'rDoc' in position 'ini' and stores it in 'str[0..m-1]'
void extractFromRLZ(uchar *ref, rlzDoc rDoc, uint ini, uint m, uchar *str){
	uint i, j, k, r, p, dt, sel;

	r = rDoc.rankB.rank(ini);
	if (rDoc.B[ini]){
		str[0]=rDoc.C[r];
		r++;
		k = r*rDoc.m;
		p = getNum64(rDoc.P, k, rDoc.m);
	}else{
		if (r){
			sel = rDoc.selB.select(r);
			dt = ini-sel-1;
			k = r*rDoc.m;
		}else{
			dt = ini;
			k=0;
		}
		p = getNum64(rDoc.P, k, rDoc.m)+dt;
		str[0]=ref[p];
		p++;
	}

	for(j=1, i=ini+1; j<m; j++, i++){
		if (rDoc.B[i]){
			str[j]=rDoc.C[r];
			r++;
			k += rDoc.m;
			p = getNum64(rDoc.P, k, rDoc.m);
		}else{
			str[j]=ref[p];
			p++;
		}
	}
}

int searchNewPrha(ParamProgram *par, string query, uint *lenP){
	size_t lb, rb, c;
	size_t occs = backward_search_beta(par->fmi, 0, par->fmi.size()-1, query.begin(), query.end(), lb, rb, c);
	//cout << "# of occurrences: " << occs << ", c = " << c << endl;
	//cout << "Suff = " << par->fmi[lb] << endl;
	if (occs){
		*lenP = c;
		return par->fmi[lb];
	}

	cout << "ERROR 0 occ" << endl;
	exit(0);

	return 0;
}

// rlz for doc[k]
void applyRLZ(ParamProgram *par, uint k){
	uint i, j, c, n, m, lenP, phra, maxP;
	uint *P;	// auxiliary structure for pointers

	n = par->rlz[k].n;
	par->N += n;
	bit_vector BitSt(n, 0);
	P = new uint[n/2];				// maximum possible numbers of lz77 phrases is n/2 (very worst case)
	uchar *C = new uchar[n/2];
	string query((char *) (par->T[k]));
	C[0]=par->T[k][n-1];
	query = query.substr(0,n-1);	// the last symbol is stored in C
	phra=maxP=0;
	i=n-1;

	while(i>0){
		j = searchNewPrha(par, query, &lenP);
		P[phra] = j;
		if(j>maxP)
			maxP=j;
		if (phra)
			C[phra]=par->T[k][i];
		phra++;
		BitSt[i] = 1;

		if (i >= lenP){
			i -= lenP;
			if (i){
				i--;
				if (i)
					query = query.substr(0,i);
				else{
					// new phrase with only one character
					C[phra]=par->T[k][0];
					BitSt[0] = 1;
					P[phra] = 0;
					phra++;
				}
				//cout << "query = " << query << endl;
			}else break;
		}else break;
	}
	//cout << "maxP = " << maxP << endl;

	par->rlz[k].m = m = 1+log2(maxP+1);
	par->rlz[k].nPhra = phra;
	par->rlz[k].C = new uchar[phra];
	par->sizeDS += phra*sizeof(uchar);

	lenP = phra*m/W64;
	if ((phra*m) %W64)
		lenP++;
	par->rlz[k].nWP = lenP;
	par->rlz[k].P = new ulong[lenP];
	par->sizeDS += lenP*sizeof(ulong);

	for (i=c=0,j=phra; j; i++, c+=m){
		j--;
		setNum64(par->rlz[k].P, c, m, P[j]);
		par->rlz[k].C[i] = C[j];
	}
	delete [] P;
	delete [] C;

	par->rlz[k].B = bit_vector_il<512>(BitSt);
	par->rlz[k].rankB = bit_vector_il<512>::rank_1_type(&(par->rlz[k].B));
	par->rlz[k].selB = bit_vector_il<512>::select_1_type(&(par->rlz[k].B));
	par->sizeDS += size_in_bytes(par->rlz[k].B);

	if (PRINT){
		cout << "B = ";
		for (i=0; i<n; i++)
			cout << BitSt[i];
		cout << endl;

		cout << "C = ";
		for (i=0; i<phra; i++)
			cout << par->rlz[k].C[i];
		cout << endl;

		cout << "P = ";
		for (i=c=0; i<phra; i++, c+=m)
			cout << getNum64(par->rlz[k].P, c, m) << " ";
		cout << endl;
	}
	par->rlz[k].n = n;
}

void makeRLZ(ParamProgram *par){
	uint i;
	storeFiles(par);

	for(i=0; i<par->d; i++)
		applyRLZ(par, i);

}

// it builds the fmi for the reference file
void buildFMI(ParamProgram *par){
	std::ifstream input;
	char fileName[400], reference[400];
	ulong len;

	// create the FMI for the reference...
	cout << " Making the FMI for the reference ..." << endl;
	std::ifstream in(par->inputFile);
	string line;

	par->d = 0;
	std::getline(in,line);
	while(in){
		if (par->d == 0){
			strcpy(reference,line.c_str());
			cout << "Reference file: " << reference << endl;
			input = ifstream(reference);
			assert(input.good());
			input.seekg(0, ios_base::end);
			par->n = par->N  = (size_t)input.tellg();
			par->ref = new uchar[par->n];
			input.seekg(0, ios_base::beg);	// move back to the beginning
			if (input.good())
				input.read((char *)par->ref, par->n);
			input.close();
			//cout << par->ref << endl;
			(par->d)++;
		} else {
			strcpy(fileName,line.c_str());
			input = ifstream(fileName);
			assert(input.good());
			input.seekg(0, ios_base::end);
			len = (size_t)input.tellg();
			input.close();
			if(len > 1){
				(par->d)++;
				//cout << "file " << par->d-1 << ":" << fileName << endl;
			}else
				cout << "bad file: " << fileName << endl;
		}
		std::getline(in,line);
	}
	(par->d)--;
	in.close();

	construct(par->fmi, reference, 1); // generate index
	cout << " **  FMI size " << size_in_bytes(par->fmi) << " bytes = " << (float)size_in_bytes(par->fmi)/(float)par->n << "|T|" << endl;
	cout << " **  FMI length " << par->fmi.size() << endl;
	strcpy(fileName, "");
	strcpy(fileName, par->prefixResult);
	strcat(fileName, "fmi.test");
	cout << "fmi stored in: " << fileName << endl;
	store_to_file(par->fmi, fileName);

	cout << "Documents for compression : " << par->d << endl;
}

void runExtractExp(ParamProgram *par, uint m){
	ulong k;
	double t, avgTime;
	uchar *substr = new uchar[m];
	uint d, randPos;
	uint min = m+2, c=0;

	cout << "____________________________________________________" << endl;
	cout << " Extract from Explicit text for " << REPET << " random strings of length m = " << m << endl;
	avgTime = 0.0;

	for (k=0; k<REPET; k++){
		d = rand() % par->d;
		if (par->rlz[d].n > min){
			randPos = rand() % (par->rlz[d].n-min);
			c++;
			t = clock();
			extractFromSeq(par->T[d], randPos, m, substr);
			t = clock() - t;

			avgTime += (float)t/CLOCKS_PER_SEC;
		}
	}
	if (c){
		cout << "Average CPU Total Time      : " << (avgTime*1000000.0)/c << " Microseconds" << endl;
		cout << "Average CPU time for symbol : " << (avgTime*1000000000.0)/c/m << " Nanoseconds" << endl;
	}else
		cout << "There are no extract for this m. The files are so smaller!!" << endl;
	cout << "----------------------------------------------------" << endl;
}

void runExtract(ParamProgram *par, uint m){
	ulong k;
	double t, avgTime;
	uchar *substr = new uchar[m];
	uint d, randPos;
	uint min = m+2, c=0;
	rlzDoc rDoc;

	cout << "____________________________________________________" << endl;
	cout << " RLZ Extract " << REPET << " random strings of length m = " << m << endl;
	avgTime = 0.0;

	for (k=0; k<REPET; k++){
		d = rand() % par->d;
		if (par->rlz[d].n > min){
			c++;
			rDoc = par->rlz[d];
			randPos = rand() % (par->rlz[d].n-min);

			t = clock();
			extractFromRLZ(par->ref, rDoc, randPos, m, substr);
			t = clock() - t;

			avgTime += (float)t/CLOCKS_PER_SEC;
		}
	}
	if (c){
		cout << "Average CPU Total Time      : " << (avgTime*1000000.0)/c << " Microseconds" << endl;
		cout << "Average CPU time for symbol : " << (avgTime*1000000000.0)/c/m << " Nanoseconds" << endl;
	}else
		cout << "There are no extract for this m. The files are so smaller!!" << endl;
	cout << "----------------------------------------------------" << endl;
}

void runExperimentExtract(ParamProgram *par){
	uint m=8;
	for (; m<=MAX; m*=4)
		runExtractExp(par, m);

	cout << "================================================" << endl;
	for (m=8; m<=MAX; m*=4)
		runExtract(par, m);
}

void storeFiles(ParamProgram *par){
	uint len, k;
	std::ifstream input;
	char fileName[400];
	string line;
	std::ifstream in(par->inputFile);

	std::getline(in,line);	// reference!
	std::getline(in,line);
	par->d=0;
	while(in){
		strcpy(fileName,line.c_str());
		std::ifstream input(fileName);
		assert(input.good());
		input.seekg(0, ios_base::end);
		len = (size_t)input.tellg();
		if(len > 1)
			(par->d)++;
		input.close();
		std::getline(in,line);
	}
	in.close();

	std::ifstream in2(par->inputFile);
	std::getline(in2,line);	// reference!
	std::getline(in2,line);
	uchar **T = new uchar*[par->d];	// we store the sequence for test
	par->rlz = new rlzDoc[par->d];	// structure for the d documents
	k = 0;
	while(in2){
		strcpy(fileName,line.c_str());
		std::ifstream input(fileName);
		assert(input.good());
		input.seekg(0, ios_base::end);
		len = (size_t)input.tellg();
		if(len > 1){
			par->rlz[k].n = len;
			input.seekg(0, ios_base::beg);
			T[k] = new uchar[len];
			input.read((char *)T[k], len);
			if (PRINT)
				cout << "d=" <<k<< " ,T = [" << T[k] << "]" << endl;
			k++;
		}
		input.close();
		std::getline(in2,line);
	}
	in2.close();
	par->T = T;
}

void testRLZ(ParamProgram *par){
	uint i, d, randPos;
	rlzDoc rDoc;
	uchar *substr;

	uchar **T = par->T;

	for (uint m=1; m<=MAX; m*=2){
		cout << "Test ... Extracting patterns for m = " << m << endl;
		substr = new uchar[m];
		for (ulong t=0; t<REPET; t++){
			d = rand() % par->d;
			rDoc = par->rlz[d];
			if (par->rlz[d].n > m+2){
				randPos = rand() % (par->rlz[d].n-m-2);
				extractFromRLZ(par->ref, rDoc, randPos, m, substr);
				for(i=0; i<m; i++){
					if ((int)(substr[i]) != (int)(T[d][randPos+i]) && (256+(int)(substr[i]) != (int)(T[d][randPos+i]))){
						cout << "ERROR: m=" << m << ", test=" << t << ", ini = " << randPos << ", doc = " << d << endl;
						cout << "substr = [" << substr << "]" << endl;
						cout << "Different symbol in position " << i << ", substr[i] = [" << substr[i] << "] != T[d][i] = [" << T[d][randPos+i] << "]" << endl;
						cout << "(int)(substr[i]) = " << (int)(substr[i]) << ", (int)(T[d][i]) = " << (int)(T[d][randPos+i]) << endl;
						exit(-2);
					}
				}
			}
		}
		delete [] substr;
	}
}


